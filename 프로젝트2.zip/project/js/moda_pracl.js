$(function(){
    // 	이미지 클릭시 해당 이미지 모달
    //     $("img").click(function(){
    //         $(".modal-overlay").show();
    //         // 해당 이미지 가져오기
    //         var imgSrc = $(this).children("img").attr("src");
    //         var imgAlt = $(this).children("img").attr("alt");
    //         $(".modal-window img").attr("src", imgSrc);
    //         $(".modal-window img").attr("alt", imgAlt);
            
    //         // 해당 이미지 텍스트 가져오기
    //         var imgTit =  $(this).children("p").text();
    //         $(".modal-window p").text(imgTit);
            
    //    // 해당 이미지에 alt값을 가져와 제목으로
    //         //$(".modalBox p").text(imgAlt);
    //     });

        let modalOpen = $("img").click(function(){
            $(".modal-overlay").show();
            // 해당 이미지 가져오기
            var imgSrc = $(this).children("img").attr("src");
            var imgAlt = $(this).children("img").attr("alt");
            $(".modal-window1 img").attr("src", imgSrc);
            $(".modal-window1 img").attr("alt", imgAlt);
            
            // 해당 이미지 텍스트 가져오기
            var imgTit =  $(this).children("p").text();
            $(".modal-window p").text(imgTit);
            
       // 해당 이미지에 alt값을 가져와 제목으로
            //$(".modalBox p").text(imgAlt);
        });

        modalOpen();


        
        //.modal안에 button을 클릭하면 .modal닫기
        $(".modal-overlay button").click(function(){
            $(".modal-overlay").hide();
        });
        
        //.modal밖에 클릭시 닫힘
        $(".modal-overlay").click(function (e) {
        if (e.target.className != "modal-overlay") {
          return false;
        } else {
          $(".modal-overlay").hide();
        }
      });
    });